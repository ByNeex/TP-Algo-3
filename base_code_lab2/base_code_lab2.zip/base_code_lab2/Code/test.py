

note = [14.5, 6, 7.5, 15, 2, 12.5, 5, 4.75, 4, 2.5, 11, 1.5, 10.75, 7.5, 4.75, 14.75, 9.5, 5.5, 12.5, 7, 9, 1, 12.5, 9.5,
        14.5, 3, 8.5, 12.5, 10.5, 5, 5.5, 14, 12, 9, 8, 12.25, 19.25, 10, 7, 6, 10.5, 6.5, 9, 6.5, 11, 6.5, 11, 8, 12, 10,
        15, 6.75, 10, 7, 10, 7.5, 4, 5.5, 9.5, 8, 11, 7.5, 14, 10, 13, 10.5, 9.5, 6.5, 13, 11, 5.5, 17, 13.5, 15.5, 9, 11.75,
        9.5, 13.5, 10.5, 11.5, 10, 12.5, 12.5, 15.5, 13.5, 12, 19.5, 6, 2.5, 13.75, 13, 12.5, 5.25, 7, 10.5, 14, 8.5, 12.5, 14.5,
        12.5, 15, 5.5, 5.5
        ]

def mediane(listeNote):
    listeTriee = sorted(listeNote)
    if (len(listeTriee) % 2) == 1:
        return listeTriee[len(listeTriee)//2]
    return (listeTriee[(len(listeTriee)//2)-1]+ listeTriee[(len(listeTriee)//2)]) / 2

somme = sum(note)
moy = somme / 103
etendue = max(note) - min(note)
print("La médiane est : ", mediane(note))
print("L'étendue est : ", etendue)
print("La moyenne est : ", moy)
